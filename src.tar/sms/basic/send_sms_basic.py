import http.client

"""
 * Send an sms message by using Infobip API.
 *
 * This example is already pre-populated with your account data:
 * 1. Your account Base URL
 * 2. Your account API key
 * 3. Your recipient phone number
 *
 * THIS CODE EXAMPLE IS READY BY DEFAULT. HIT RUN TO SEND THE MESSAGE!
 *
 * Send sms API reference: https://www.infobip.com/docs/api#channels/sms/send-sms-message
 * See Readme file for details.
"""

BASE_URL = "ej23g2.api.infobip.com"
API_KEY = "App a8a0491b7117dd3242a73b437cc03c88-6f95bc75-1966-4ad1-b5dc-98ac94ccf5af"

SENDER = "InfoSMS"
RECIPIENT = "2349077393129"
MESSAGE_TEXT = "This is a sample message"

conn = http.client.HTTPSConnection(BASE_URL)

payload1 = "{\"messages\":" \
          "[{\"from\":\"" + SENDER + "\"" \
          ",\"destinations\":" \
          "[{\"to\":\"" + RECIPIENT + "\"}]," \
          "\"text\":\"" + MESSAGE_TEXT + "\"}]}"

headers = {
    'Authorization': API_KEY,
    'Content-Type': 'application/json',
    'Accept': 'application/json'
}
conn.request("POST", "/sms/2/text/advanced", payload1, headers)

res = conn.getresponse()
data = res.read()
print(data.decode("utf-8"))
